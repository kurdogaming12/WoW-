const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const cors = require('cors');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const { Pool } = require('pg');
const FormData = require('form-data');
const fileUpload = require('express-fileupload');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
require('dotenv').config();

const config = require('./config');

const app = express();
const pool = new Pool({ connectionString: config.database.url });

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(fileUpload({ limits: { fileSize: 8 * 1024 * 1024 } }));
app.use(cors({ origin: '*', credentials: true }));
app.use(session({
    secret: config.session.secret,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true }
}));
app.use(passport.initialize());
app.use(passport.session());

// Only initialize Discord strategy if credentials are available
if (config.discord.clientID !== 'YOUR_DISCORD_CLIENT_ID_HERE' && config.discord.clientSecret !== 'YOUR_DISCORD_CLIENT_SECRET_HERE') {
    passport.use(new DiscordStrategy({
        clientID: config.discord.clientID,
        clientSecret: config.discord.clientSecret,
        callbackURL: 'https://placeholder.replit.dev/auth/discord/callback',
        passReqToCallback: true,
        scope: ['identify', 'email']
    }, async (req, accessToken, refreshToken, profile, done) => {
        try {
            const result = await pool.query(
                'INSERT INTO users (discord_id, username, email) VALUES ($1, $2, $3) ON CONFLICT (discord_id) DO UPDATE SET username=$2, email=$3 RETURNING *',
                [profile.id, profile.username, profile.email]
            );
            return done(null, result.rows[0]);
        } catch (err) {
            return done(err);
        }
    }));

    passport.serializeUser((user, done) => {
        done(null, user.id);
    });

    passport.deserializeUser(async (id, done) => {
        try {
            const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
            done(null, result.rows[0]);
        } catch (err) {
            done(err);
        }
    });
}

// Serve static files
app.use(express.static('.'));

// Initialize or get bot stats
async function getOrCreateStats() {
    try {
        const result = await pool.query('SELECT * FROM bot_stats WHERE id = 1');
        if (result.rows.length === 0) {
            const create = await pool.query(
                'INSERT INTO bot_stats (id, servers, users) VALUES (1, 50000, 500000) RETURNING *'
            );
            return create.rows[0];
        }
        return result.rows[0];
    } catch (err) {
        console.log('Stats table not initialized yet');
        return null;
    }
}

// Email setup
const transporter = nodemailer.createTransport({
    service: config.email.service,
    auth: {
        user: config.email.user,
        pass: config.email.password
    }
});

// Generate verification code
function generateCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Get support contact info
app.get('/api/support-info', (req, res) => {
    res.json({
        discordName: config.support.discordName,
        discordLogo: config.support.discordLogo,
        inviteUrl: config.links.invite,
        serverUrl: config.links.server
    });
});

// Get stats endpoint
app.get('/api/stats', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM bot_stats WHERE id = 1');
        if (result.rows.length > 0) {
            res.json(result.rows[0]);
        } else {
            res.json({ id: 1, servers: 50000, users: 500000 });
        }
    } catch (err) {
        console.error('Error fetching stats:', err);
        res.json({ id: 1, servers: 50000, users: 500000 });
    }
});

// Update stats when bot joins server
app.post('/api/stats/server-join', async (req, res) => {
    try {
        const result = await pool.query(
            'UPDATE bot_stats SET servers = servers + 1 WHERE id = 1 RETURNING *'
        );
        if (result.rows.length > 0) {
            res.json({ success: true, stats: result.rows[0] });
        } else {
            const init = await pool.query(
                'INSERT INTO bot_stats (id, servers, users) VALUES (1, 50001, 500000) RETURNING *'
            );
            res.json({ success: true, stats: init.rows[0] });
        }
    } catch (err) {
        console.error('Error updating stats:', err);
        res.status(500).json({ error: 'Error updating stats' });
    }
});

// Update users count
app.post('/api/stats/user-join', async (req, res) => {
    try {
        const result = await pool.query(
            'UPDATE bot_stats SET users = users + 1 WHERE id = 1 RETURNING *'
        );
        if (result.rows.length > 0) {
            res.json({ success: true, stats: result.rows[0] });
        } else {
            const init = await pool.query(
                'INSERT INTO bot_stats (id, servers, users) VALUES (1, 50000, 500001) RETURNING *'
            );
            res.json({ success: true, stats: init.rows[0] });
        }
    } catch (err) {
        console.error('Error updating users:', err);
        res.status(500).json({ error: 'Error updating users' });
    }
});

// Show callback URL based on request domain
app.get('/callback-url', (req, res) => {
    const protocol = req.protocol || 'https';
    const host = req.get('host') || 'localhost:5000';
    const callbackUrl = `${protocol}://${host}/auth/discord/callback`;
    
    res.send(`
        <h1>Your Discord Callback URL</h1>
        <p>Use this exact URL in Discord:</p>
        <code style="background: #f0f0f0; padding: 10px; display: block; margin: 20px 0; border-radius: 5px;">
            ${callbackUrl}
        </code>
        <p>Copy and paste it in Discord's OAuth2 Redirects section.</p>
    `);
});

// Discord OAuth routes
app.get('/auth/discord', (req, res) => {
    if (config.discord.clientID === 'YOUR_DISCORD_CLIENT_ID_HERE') {
        return res.status(500).send('Discord OAuth not configured. Please update config.js with your Discord credentials.');
    }
    passport.authenticate('discord', {
        callbackURL: `${req.protocol}://${req.get('host')}${config.discord.callbackPath}`
    })(req, res);
});

app.get('/auth/discord/callback', 
    (req, res, next) => {
        if (config.discord.clientID === 'YOUR_DISCORD_CLIENT_ID_HERE') {
            return res.status(500).send('Discord OAuth not configured. Please update config.js with your Discord credentials.');
        }
        passport.authenticate('discord', { 
            failureRedirect: '/',
            callbackURL: `${req.protocol}://${req.get('host')}${config.discord.callbackPath}`
        })(req, res, next);
    },
    (req, res) => {
        res.redirect('/');
    }
);

// Get current user
app.get('/api/user', (req, res) => {
    res.json(req.user || null);
});

// Logout
app.get('/logout', (req, res) => {
    req.logout((err) => {
        if (err) return res.status(500).json({ error: 'Logout failed' });
        res.redirect('/');
    });
});

// Report endpoint
app.post('/api/report', async (req, res) => {
    const { type, content, discordUser } = req.body;
    const webhookUrl = config.discord.webhookUrl;

    if (!webhookUrl) {
        console.error('DISCORD_WEBHOOK_URL is not set');
        return res.status(500).json({ error: 'Configuration error: DISCORD_WEBHOOK_URL is missing.' });
    }

    try {
        const form = new FormData();
        const embed = {
            title: 'New Report from Website',
            color: type === 'bug' ? 15158332 : 3066993,
            fields: [
                { name: 'Discord User', value: discordUser || 'Not provided', inline: true },
                { name: 'Type', value: type, inline: true },
                { name: 'Description', value: content }
            ],
            timestamp: new Date().toISOString()
        };
        
        form.append('payload_json', JSON.stringify({ embeds: [embed] }));
        
        if (req.files) {
            if (req.files.photo) {
                form.append('files[0]', req.files.photo.data, req.files.photo.name);
            }
            if (req.files.video) {
                form.append('files[1]', req.files.video.data, req.files.video.name);
            }
        }

        const response = await fetch(webhookUrl, {
            method: 'POST',
            body: form,
            headers: form.getHeaders()
        });

        if (response.ok) {
            res.json({ success: true });
        } else {
            const responseText = await response.text();
            throw new Error(`Discord API error: ${response.status} ${responseText}`);
        }
    } catch (error) {
        console.error('Error sending report:', error);
        res.status(500).json({ error: 'Error sending report to Discord.' });
    }
});

const PORT = config.server.port;
app.listen(PORT, config.server.host, () => {
    console.log(`Backend running on port ${PORT}`);
});