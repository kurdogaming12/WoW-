# WoW Bot Website - Quick Start

## ✓ What's Already Done

1. **Server Running** - Website is live at your Replit URL
2. **Discord Credentials Configured** - Client ID and Secret are in config.js
3. **Database Setup** - User database is ready to store logins
4. **Callback URL Auto-Setup** - Works automatically on any domain

## 📋 Final Step: Discord Setup

To enable Discord login, you need to register your callback URL in Discord:

1. **Open Discord Developer Portal**
   - Go to: https://discord.com/developers/applications
   - Select: "WoW Bot Website" app

2. **Add Callback URL**
   - Go to: OAuth2 → Redirects
   - Click "Add Redirect"
   - Paste your Replit URL + callback:
     ```
     https://YOUR-REPLIT-URL/auth/discord/callback
     ```
   - Replace `YOUR-REPLIT-URL` with your actual Replit URL
   - Click "Save Changes"

3. **Done!**
   - Discord login is now active on your website
   - Users can click "Login with Discord" button

## 🎮 Features Ready to Use

- ✓ Discord OAuth Login
- ✓ User account storage
- ✓ Bug report submission
- ✓ Responsive design
- ✓ Admin webhook notifications

## 📝 Configuration Files

- **config.js** - All settings in one place
- **.env.example** - Environment variables template
- **DISCORD_SETUP.md** - Detailed Discord setup guide

## 🚀 Your Website Features

### Navigation
- Logo and title
- "Write Report" button
- Login/Logout button (shows username when logged in)

### Hero Section
- Eye-catching banner
- "Invite Bot" button
- "Server Link" button

### Rules Section
- Server rules
- Support information

### Report Modal
- Submit bug reports
- User reports
- Feedback
- Messages sent directly to your Discord server

Enjoy your Discord bot website! 🎉
