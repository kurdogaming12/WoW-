# Discord OAuth Setup Guide

## Step 1: Create a Discord Application

1. Go to https://discord.com/developers/applications
2. Click "New Application" and name it "WoW Bot Website"
3. Go to the "OAuth2" section in the left sidebar
4. Copy your **Client ID** and **Client Secret**

## Step 2: Add Redirect URL

In the OAuth2 section, add your redirect URL under "Redirects":

```
https://YOUR-REPLIT-URL/auth/discord/callback
```

Replace `YOUR-REPLIT-URL` with your actual Replit project URL (e.g., `wow-bot-website.replit.dev`)

## Step 3: Configure Environment Variables

Go to the Replit "Secrets" tab (lock icon) and add:

- **DISCORD_CLIENT_ID**: Your Client ID from step 1
- **DISCORD_CLIENT_SECRET**: Your Client Secret from step 1
- **SESSION_SECRET**: Any random string (e.g., `your-random-secret-key-123`)
- **DISCORD_WEBHOOK_URL**: (Optional) Your Discord webhook URL for reports

## Step 4: Start the Server

The Discord login button will automatically appear on your website!

### How it works:
- Users click "Login with Discord" button
- They are redirected to Discord for authentication
- After approving, they return to your site as logged-in users
- Their username appears in the navigation bar
- They can logout with the "Logout" link
