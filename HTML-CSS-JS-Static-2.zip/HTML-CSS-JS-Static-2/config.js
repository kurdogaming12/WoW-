// WoW Bot Website Configuration
// Edit all your settings here

module.exports = {
    // Discord OAuth Settings
    discord: {
        clientID: process.env.DISCORD_CLIENT_ID || '1435231049033584722',
        clientSecret: process.env.DISCORD_CLIENT_SECRET || 'D6sfybzrnYrblD4HKQTImsDhEzHu3lTR',
        // Callback URL - will be set dynamically in server.js based on request host
        callbackPath: '/auth/discord/callback',
        webhookUrl: process.env.DISCORD_WEBHOOK_URL || 'https://discord.com/api/webhooks/1454563265505132649/gtL6PvmbjCSmbXWLR6QgHSiV1jdalLeHUSIs5fiNXK8HddOXerlO9d-1lKwtJNXX_bRx'
    },

    // Session Settings
    session: {
        secret: process.env.SESSION_SECRET || 'your-session-secret-key-change-this'
    },

    // Bot Links
    links: {
        invite: process.env.BOT_INVITE_URL || 'https://discord.com/oauth2/authorize?client_id=1435231049033584722&scope=bot',
        server: process.env.SERVER_LINK || 'https://discord.gg/DEINSERVER'
    },

    // Server Settings
    server: {
        port: 5000,
        host: '0.0.0.0'
    },

    // Database (Auto-configured by Replit)
    database: {
        url: process.env.DATABASE_URL || 'postgresql://...'
    },

    // Support Contact Info
    support: {
        discordName: process.env.SUPPORT_DISCORD_NAME || 'KURDO 09',
        discordLogo: process.env.SUPPORT_DISCORD_LOGO || 'attached_assets/E14F0BE8-3D29-4C18-85F2-A75AF12F95E0_1766922280005.jpeg'
    },

    // Email Settings
    email: {
        service: 'gmail',
        user: process.env.EMAIL_USER || 'your-email@gmail.com',
        password: process.env.EMAIL_PASSWORD || 'your-app-password'
    }
};
